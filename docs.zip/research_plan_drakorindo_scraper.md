# Rencana Penelitian: Web Scraper drakorindo.fun

## Tujuan
- Menganalisis struktur website drakorindo.fun untuk mengidentifikasi elemen data yang relevan.
- Mengembangkan script Python yang kuat untuk mengambil data drama Korea dari situs tersebut.
- Menghasilkan output data dalam format JSON yang terstruktur sesuai dengan spesifikasi yang diberikan.
- Memastikan scraper dapat diandalkan dengan penanganan kesalahan, penundaan, dan User-Agent yang sesuai.

## Rincian Penelitian
- **Analisis Situs Web**:
  - Sub-tugas 1.1: Investigasi struktur HTML dari halaman detail drama.
  - Sub-tugas 1.2: Identifikasi lokasi judul drama, gambar sampul, genre, dan sinopsis.
  - Sub-tugas 1.3: Analisis daftar episode dan cara mengekstrak tautan video untuk setiap episode.
  - Sub-tugas 1.4: Periksa mekanisme anti-scraping yang mungkin ada.
- **Pengembangan Scraper**:
  - Sub-tugas 2.1: Implementasi pengambilan HTML menggunakan `requests`.
  - Sub-tugas 2.2: Parsing HTML menggunakan `BeautifulSoup`.
  - Sub-tugas 2.3: Ekstraksi data yang dibutuhkan (judul, sampul, genre, sinopsis, episode).
  - Sub-tugas 2.4: Penambahan User-Agent yang realistis dan penundaan antar permintaan.
  - Sub-tugas 2.5: Implementasi penanganan kesalahan dan mekanisme percobaan ulang.
- **Output dan Pengujian**:
  - Sub-tugas 3.1: Strukturisasi data yang diambil ke dalam format JSON yang ditentukan.
  - Sub-tugas 3.2: Penulisan data ke file `drama.json`.
  - Sub-tugas 3.3: Pengujian scraper pada beberapa drama untuk memastikan fungsionalitas dan akurasi data.

## Pertanyaan Kunci
1. Bagaimana struktur DOM dari halaman drama di drakorindo.fun? Elemen dan kelas CSS apa yang berisi data yang dibutuhkan?
2. Bagaimana tautan video disematkan? Apakah memerlukan interaksi lebih lanjut (misalnya, JavaScript) untuk mengungkapnya?
3. Format video apa yang tersedia (.mp4, .m3u8, dll.) dan bagaimana cara menanganinya?
4. Apa saja potensi tantangan dalam melakukan scraping pada situs ini (misalnya, CAPTCHA, pemblokiran IP)?

## Strategi Sumber Daya
- Sumber data utama: `https://drakorindo.fun/`
- Alat utama: `requests`, `BeautifulSoup4`, `json` di Python.
- Strategi pencarian: Fokus pada analisis HTML statis terlebih dahulu. Jika konten dimuat secara dinamis, selidiki permintaan jaringan menggunakan alat pengembang browser.

## Rencana Verifikasi
- Persyaratan sumber: Data akan diverifikasi langsung dari situs web drakorindo.fun.
- Validasi silang: Menjalankan scraper pada beberapa halaman drama yang berbeda dan membandingkan output JSON secara manual dengan konten situs untuk memastikan akurasi.

## Hasil yang Diharapkan
- Script Python lengkap (`drakorindo_scraper.py`) yang dapat dijalankan untuk mengambil data.
- File output `drama.json` yang berisi data drama yang diambil dalam format yang benar.
- Dokumentasi singkat tentang cara menjalankan script dan dependensinya.

## Pemilihan Alur Kerja
- Fokus utama: **Pencarian** (Search-focused)
- Pembenaran: Alur kerja ini paling sesuai karena tugas utamanya adalah mengumpulkan informasi (scraping) dari sumber web. Fase awal akan berkonsentrasi pada penemuan dan ekstraksi data. Verifikasi akan dilakukan setelah data awal dikumpulkan.
